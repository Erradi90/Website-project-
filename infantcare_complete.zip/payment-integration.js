// payment-integration.js
// JavaScript for payment integration with PayPal, Apple Pay, and Google Pay

document.addEventListener('DOMContentLoaded', function() {
    // Initialize payment methods based on availability
    initializePaymentMethods();
});

// Initialize available payment methods
function initializePaymentMethods() {
    // Check if PayPal is available
    if (typeof paypal !== 'undefined') {
        initializePayPal();
    } else {
        console.log('PayPal SDK not loaded');
    }
    
    // Check if Apple Pay is available
    if (window.ApplePaySession && ApplePaySession.canMakePayments()) {
        initializeApplePay();
    } else {
        console.log('Apple Pay not available on this device/browser');
        document.getElementById('apple-pay').disabled = true;
        document.querySelector('label[for="apple-pay"]').classList.add('text-gray-400');
    }
    
    // Check if Google Pay is available
    if (window.google && google.payments && google.payments.api) {
        initializeGooglePay();
    } else {
        console.log('Google Pay not available');
        document.getElementById('google-pay').disabled = true;
        document.querySelector('label[for="google-pay"]').classList.add('text-gray-400');
    }
}

// Initialize PayPal
function initializePayPal() {
    // This function would normally integrate with the PayPal SDK
    // For demonstration purposes, we're just logging to console
    console.log('PayPal initialized');
    
    // In a real implementation, you would render the PayPal button like this:
    /*
    paypal.Buttons({
        createOrder: function(data, actions) {
            // Get cart items and calculate total
            const cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
            const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) * 1.15;
            
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        currency_code: 'SAR',
                        value: total.toFixed(2)
                    }
                }]
            });
        },
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                // Handle successful payment
                processSuccessfulPayment('paypal', details.id);
            });
        }
    }).render('#paypalContainer');
    */
}

// Initialize Apple Pay
function initializeApplePay() {
    // This function would normally integrate with the Apple Pay JS API
    // For demonstration purposes, we're just logging to console
    console.log('Apple Pay initialized');
    
    // In a real implementation, you would set up Apple Pay like this:
    /*
    const applePayButton = document.getElementById('applePayButton');
    
    applePayButton.addEventListener('click', function() {
        // Get cart items and calculate total
        const cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) * 1.15;
        
        // Create payment request
        const paymentRequest = {
            countryCode: 'SA',
            currencyCode: 'SAR',
            supportedNetworks: ['visa', 'masterCard', 'amex'],
            merchantCapabilities: ['supports3DS'],
            total: {
                label: 'رعاية الأطفال',
                amount: total.toFixed(2)
            }
        };
        
        // Create Apple Pay session
        const session = new ApplePaySession(3, paymentRequest);
        
        session.onvalidatemerchant = function(event) {
            // Validate merchant session with your server
            fetch('/validate-merchant', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    validationURL: event.validationURL
                })
            })
            .then(res => res.json())
            .then(merchantSession => {
                session.completeMerchantValidation(merchantSession);
            })
            .catch(error => {
                console.error('Error validating merchant:', error);
                session.abort();
            });
        };
        
        session.onpaymentauthorized = function(event) {
            // Process payment with your server
            fetch('/process-apple-pay', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    payment: event.payment
                })
            })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    session.completePayment(ApplePaySession.STATUS_SUCCESS);
                    processSuccessfulPayment('apple-pay', result.transactionId);
                } else {
                    session.completePayment(ApplePaySession.STATUS_FAILURE);
                }
            })
            .catch(error => {
                console.error('Error processing Apple Pay payment:', error);
                session.completePayment(ApplePaySession.STATUS_FAILURE);
            });
        };
        
        session.begin();
    });
    */
}

// Initialize Google Pay
function initializeGooglePay() {
    // This function would normally integrate with the Google Pay API
    // For demonstration purposes, we're just logging to console
    console.log('Google Pay initialized');
    
    // In a real implementation, you would set up Google Pay like this:
    /*
    const googlePayClient = new google.payments.api.PaymentsClient({
        environment: 'TEST' // or 'PRODUCTION'
    });
    
    const googlePayButton = document.getElementById('googlePayButton');
    
    googlePayClient.isReadyToPay({
        apiVersion: 2,
        apiVersionMinor: 0,
        allowedPaymentMethods: [{
            type: 'CARD',
            parameters: {
                allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                allowedCardNetworks: ['VISA', 'MASTERCARD', 'AMEX']
            }
        }]
    })
    .then(function(response) {
        if (response.result) {
            googlePayButton.addEventListener('click', function() {
                // Get cart items and calculate total
                const cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
                const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) * 1.15;
                
                const paymentDataRequest = {
                    apiVersion: 2,
                    apiVersionMinor: 0,
                    allowedPaymentMethods: [{
                        type: 'CARD',
                        parameters: {
                            allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                            allowedCardNetworks: ['VISA', 'MASTERCARD', 'AMEX']
                        },
                        tokenizationSpecification: {
                            type: 'PAYMENT_GATEWAY',
                            parameters: {
                                gateway: 'example',
                                gatewayMerchantId: 'exampleGatewayMerchantId'
                            }
                        }
                    }],
                    merchantInfo: {
                        merchantId: '12345678901234567890',
                        merchantName: 'رعاية الأطفال'
                    },
                    transactionInfo: {
                        totalPriceStatus: 'FINAL',
                        totalPrice: total.toFixed(2),
                        currencyCode: 'SAR'
                    }
                };
                
                googlePayClient.loadPaymentData(paymentDataRequest)
                .then(function(paymentData) {
                    // Process payment with your server
                    fetch('/process-google-pay', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            paymentData: paymentData
                        })
                    })
                    .then(res => res.json())
                    .then(result => {
                        if (result.success) {
                            processSuccessfulPayment('google-pay', result.transactionId);
                        } else {
                            console.error('Payment processing failed');
                        }
                    })
                    .catch(error => {
                        console.error('Error processing Google Pay payment:', error);
                    });
                })
                .catch(function(error) {
                    console.error('Error loading payment data:', error);
                });
            });
        } else {
            console.log('Google Pay not available');
            document.getElementById('google-pay').disabled = true;
            document.querySelector('label[for="google-pay"]').classList.add('text-gray-400');
        }
    })
    .catch(function(error) {
        console.error('Error checking Google Pay availability:', error);
    });
    */
}

// Process successful payment
function processSuccessfulPayment(paymentMethod, transactionId) {
    // Get cart items
    const cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
    
    // Get customer information from form
    const form = document.getElementById('checkoutForm');
    const formData = new FormData(form);
    
    // Create order object
    const order = {
        customer: {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone')
        },
        items: cart,
        paymentMethod: paymentMethod,
        transactionId: transactionId,
        total: cart.reduce((total, item) => total + (item.price * item.quantity), 0) * 1.15, // Including tax
        date: new Date().toISOString()
    };
    
    // Send order to Google Sheets
    sendOrderToGoogleSheets(order)
        .then(response => {
            if (response.success) {
                // Clear cart
                localStorage.removeItem('ebooksCart');
                
                // Show success message
                showNotification('تم إرسال طلبك بنجاح!', 'success');
                
                // Redirect to confirmation page
                setTimeout(() => {
                    window.location.href = 'order-confirmation.html?orderId=' + response.orderId;
                }, 2000);
            } else {
                showNotification('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.', 'error');
            }
        })
        .catch(error => {
            console.error('Error submitting order:', error);
            showNotification('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.', 'error');
        });
}

// Send order to Google Sheets
function sendOrderToGoogleSheets(order) {
    // Replace with your Google Apps Script Web App URL
    const scriptURL = 'YOUR_GOOGLE_SCRIPT_WEB_APP_URL';
    
    return fetch(scriptURL, {
        method: 'POST',
        body: JSON.stringify(order),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        return {
            success: true,
            orderId: data.orderId || Date.now().toString()
        };
    })
    .catch(error => {
        console.error('Error sending order to Google Sheets:', error);
        return {
            success: false,
            error: error.message
        };
    });
}

// For demonstration purposes, simulate payment processing
function simulatePaymentProcessing(paymentMethod) {
    return new Promise((resolve, reject) => {
        // Simulate processing delay
        setTimeout(() => {
            // Simulate 90% success rate
            if (Math.random() < 0.9) {
                resolve({
                    success: true,
                    transactionId: 'TRANS-' + Date.now() + '-' + Math.floor(Math.random() * 1000)
                });
            } else {
                reject(new Error('Payment processing failed'));
            }
        }, 2000);
    });
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-lg text-white z-50 ${type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-indigo-500'}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.classList.add('opacity-0', 'transition-opacity', 'duration-500');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 3000);
}
