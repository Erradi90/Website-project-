// Google Apps Script for Order Tracking
// This code should be deployed as a web app in Google Apps Script

// Set up the doPost function to handle POST requests from the website
function doPost(e) {
  try {
    // Parse the JSON data from the request
    const data = JSON.parse(e.postData.contents);
    
    // Get the active spreadsheet
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // Process orders
    const orderId = processOrder(ss, data);
    
    // Return success response with order ID
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      orderId: orderId
    }))
    .setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    // Return error response
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString()
    }))
    .setMimeType(ContentService.MimeType.JSON);
  }
}

// Process the order and add it to the Orders sheet
function processOrder(ss, data) {
  // Generate a unique order ID
  const orderId = generateOrderId();
  
  // Get or create Orders sheet
  let ordersSheet = ss.getSheetByName('Orders');
  if (!ordersSheet) {
    ordersSheet = ss.insertSheet('Orders');
    setupOrdersSheet(ordersSheet);
  }
  
  // Add order to Orders sheet
  const orderRow = [
    orderId,                                // Order ID
    new Date(),                             // Date
    data.customer.name,                     // Customer Name
    data.customer.email,                    // Customer Email
    data.customer.phone,                    // Customer Phone
    data.paymentMethod,                     // Payment Method
    data.total,                             // Total Amount
    JSON.stringify(data.items),             // Items (JSON)
    'Pending',                              // Status
    ''                                      // Notes
  ];
  
  ordersSheet.appendRow(orderRow);
  
  // Process order items
  processOrderItems(ss, orderId, data.items);
  
  // Send confirmation email
  sendConfirmationEmail(data.customer, orderId, data.items, data.total);
  
  return orderId;
}

// Set up the Orders sheet with headers
function setupOrdersSheet(sheet) {
  const headers = [
    'Order ID',
    'Date',
    'Customer Name',
    'Customer Email',
    'Customer Phone',
    'Payment Method',
    'Total Amount',
    'Items',
    'Status',
    'Notes'
  ];
  
  sheet.appendRow(headers);
  sheet.setFrozenRows(1);
  
  // Format headers
  sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');
  sheet.setColumnWidths(1, headers.length, 150);
  
  // Auto-resize columns to fit content
  sheet.autoResizeColumns(1, headers.length);
}

// Process order items and add them to the Order Items sheet
function processOrderItems(ss, orderId, items) {
  // Get or create Order Items sheet
  let itemsSheet = ss.getSheetByName('Order Items');
  if (!itemsSheet) {
    itemsSheet = ss.insertSheet('Order Items');
    setupOrderItemsSheet(itemsSheet);
  }
  
  // Add each item to the Order Items sheet
  items.forEach(item => {
    const itemRow = [
      orderId,                // Order ID
      item.id,                // Product ID
      item.name,              // Product Name
      item.price,             // Price
      item.quantity,          // Quantity
      item.price * item.quantity  // Subtotal
    ];
    
    itemsSheet.appendRow(itemRow);
  });
}

// Set up the Order Items sheet with headers
function setupOrderItemsSheet(sheet) {
  const headers = [
    'Order ID',
    'Product ID',
    'Product Name',
    'Price',
    'Quantity',
    'Subtotal'
  ];
  
  sheet.appendRow(headers);
  sheet.setFrozenRows(1);
  
  // Format headers
  sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');
  sheet.setColumnWidths(1, headers.length, 150);
  
  // Auto-resize columns to fit content
  sheet.autoResizeColumns(1, headers.length);
}

// Generate a unique order ID
function generateOrderId() {
  const timestamp = new Date().getTime().toString().slice(-6);
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return 'ORD-' + timestamp + '-' + random;
}

// Send confirmation email to customer
function sendConfirmationEmail(customer, orderId, items, total) {
  const subject = 'تأكيد طلبك - رعاية الأطفال';
  
  // Build email body
  let itemsList = '';
  items.forEach(item => {
    itemsList += `- ${item.name} (الكمية: ${item.quantity}) - ${item.price * item.quantity} ريال\n`;
  });
  
  const body = `مرحباً ${customer.name}،

شكراً لطلبك من موقع رعاية الأطفال. تم استلام طلبك بنجاح.

تفاصيل الطلب:
رقم الطلب: ${orderId}
تاريخ الطلب: ${new Date().toLocaleDateString('ar-SA')}

المنتجات:
${itemsList}

المجموع: ${total} ريال

سيتم إرسال روابط تحميل الكتب الإلكترونية إلى بريدك الإلكتروني خلال 24 ساعة من تأكيد الدفع.

إذا كان لديك أي استفسار، يرجى التواصل معنا على البريد الإلكتروني: support@infantcare.example.com

مع خالص الشكر والتقدير،
فريق رعاية الأطفال`;

  try {
    MailApp.sendEmail({
      to: customer.email,
      subject: subject,
      body: body
    });
  } catch (error) {
    Logger.log('Error sending email: ' + error.toString());
  }
}

// Set up the doGet function to handle GET requests (for testing)
function doGet() {
  return ContentService.createTextOutput(JSON.stringify({
    status: 'active',
    message: 'The order tracking API is active and ready to receive orders.'
  }))
  .setMimeType(ContentService.MimeType.JSON);
}

// Create a function to get all orders (for admin dashboard)
function getAllOrders() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ordersSheet = ss.getSheetByName('Orders');
  
  if (!ordersSheet) {
    return [];
  }
  
  const data = ordersSheet.getDataRange().getValues();
  const headers = data[0];
  const orders = [];
  
  for (let i = 1; i < data.length; i++) {
    const order = {};
    for (let j = 0; j < headers.length; j++) {
      order[headers[j]] = data[i][j];
    }
    orders.push(order);
  }
  
  return orders;
}

// Create a function to update order status
function updateOrderStatus(orderId, status) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ordersSheet = ss.getSheetByName('Orders');
  
  if (!ordersSheet) {
    return false;
  }
  
  const data = ordersSheet.getDataRange().getValues();
  const statusColumnIndex = data[0].indexOf('Status');
  
  if (statusColumnIndex === -1) {
    return false;
  }
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === orderId) {
      ordersSheet.getRange(i + 1, statusColumnIndex + 1).setValue(status);
      return true;
    }
  }
  
  return false;
}

// Create a function to get order details by ID
function getOrderById(orderId) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ordersSheet = ss.getSheetByName('Orders');
  
  if (!ordersSheet) {
    return null;
  }
  
  const data = ordersSheet.getDataRange().getValues();
  const headers = data[0];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === orderId) {
      const order = {};
      for (let j = 0; j < headers.length; j++) {
        order[headers[j]] = data[i][j];
      }
      
      // Get order items
      order.items = getOrderItems(orderId);
      
      return order;
    }
  }
  
  return null;
}

// Get order items by order ID
function getOrderItems(orderId) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const itemsSheet = ss.getSheetByName('Order Items');
  
  if (!itemsSheet) {
    return [];
  }
  
  const data = itemsSheet.getDataRange().getValues();
  const headers = data[0];
  const items = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === orderId) {
      const item = {};
      for (let j = 0; j < headers.length; j++) {
        item[headers[j]] = data[i][j];
      }
      items.push(item);
    }
  }
  
  return items;
}

// Create a function to generate sales reports
function generateSalesReport(startDate, endDate) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ordersSheet = ss.getSheetByName('Orders');
  
  if (!ordersSheet) {
    return {
      totalOrders: 0,
      totalSales: 0,
      items: []
    };
  }
  
  const data = ordersSheet.getDataRange().getValues();
  const dateColumnIndex = data[0].indexOf('Date');
  const totalColumnIndex = data[0].indexOf('Total Amount');
  const itemsColumnIndex = data[0].indexOf('Items');
  
  if (dateColumnIndex === -1 || totalColumnIndex === -1 || itemsColumnIndex === -1) {
    return {
      totalOrders: 0,
      totalSales: 0,
      items: []
    };
  }
  
  let totalOrders = 0;
  let totalSales = 0;
  const itemsSold = {};
  
  for (let i = 1; i < data.length; i++) {
    const orderDate = new Date(data[i][dateColumnIndex]);
    
    if (orderDate >= startDate && orderDate <= endDate) {
      totalOrders++;
      totalSales += data[i][totalColumnIndex];
      
      // Count items sold
      const items = JSON.parse(data[i][itemsColumnIndex]);
      items.forEach(item => {
        if (!itemsSold[item.id]) {
          itemsSold[item.id] = {
            id: item.id,
            name: item.name,
            quantity: 0,
            revenue: 0
          };
        }
        
        itemsSold[item.id].quantity += item.quantity;
        itemsSold[item.id].revenue += item.price * item.quantity;
      });
    }
  }
  
  return {
    totalOrders: totalOrders,
    totalSales: totalSales,
    items: Object.values(itemsSold)
  };
}
