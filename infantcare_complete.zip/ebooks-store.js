// ebooks-store.js
// JavaScript for eBooks store functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the shopping cart
    initializeCart();
    
    // Add event listeners to "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const productId = this.getAttribute('data-product-id');
            const productName = this.getAttribute('data-product-name');
            const productPrice = parseFloat(this.getAttribute('data-product-price'));
            const productImage = this.getAttribute('data-product-image');
            
            addToCart(productId, productName, productPrice, productImage);
            
            // Show notification
            showNotification(`تمت إضافة "${productName}" إلى سلة التسوق`);
        });
    });
    
    // Initialize payment methods
    initializePaymentMethods();
});

// Cart functionality
function initializeCart() {
    // Initialize cart from localStorage if it exists
    let cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
    updateCartDisplay(cart);
    
    // Add event listener to cart icon to show/hide cart
    const cartIcon = document.getElementById('cartIcon');
    const cartDropdown = document.getElementById('cartDropdown');
    
    if (cartIcon && cartDropdown) {
        cartIcon.addEventListener('click', function(e) {
            e.preventDefault();
            cartDropdown.classList.toggle('hidden');
        });
        
        // Close cart when clicking outside
        document.addEventListener('click', function(e) {
            if (!cartIcon.contains(e.target) && !cartDropdown.contains(e.target)) {
                cartDropdown.classList.add('hidden');
            }
        });
    }
    
    // Add event listener to checkout button
    const checkoutButton = document.getElementById('checkoutButton');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function() {
            window.location.href = 'checkout.html';
        });
    }
}

function addToCart(productId, productName, productPrice, productImage) {
    let cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
    
    // Check if product already exists in cart
    const existingProductIndex = cart.findIndex(item => item.id === productId);
    
    if (existingProductIndex > -1) {
        // Product exists, increment quantity
        cart[existingProductIndex].quantity += 1;
    } else {
        // Product doesn't exist, add new item
        cart.push({
            id: productId,
            name: productName,
            price: productPrice,
            image: productImage,
            quantity: 1
        });
    }
    
    // Save cart to localStorage
    localStorage.setItem('ebooksCart', JSON.stringify(cart));
    
    // Update cart display
    updateCartDisplay(cart);
}

function removeFromCart(productId) {
    let cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
    
    // Remove product from cart
    cart = cart.filter(item => item.id !== productId);
    
    // Save cart to localStorage
    localStorage.setItem('ebooksCart', JSON.stringify(cart));
    
    // Update cart display
    updateCartDisplay(cart);
}

function updateCartDisplay(cart) {
    const cartItemsElement = document.getElementById('cartItems');
    const cartCountElement = document.getElementById('cartCount');
    const cartTotalElement = document.getElementById('cartTotal');
    
    if (cartItemsElement) {
        // Clear current cart items
        cartItemsElement.innerHTML = '';
        
        if (cart.length === 0) {
            // Cart is empty
            cartItemsElement.innerHTML = '<div class="py-4 text-center text-gray-500">سلة التسوق فارغة</div>';
            
            // Hide checkout button
            const checkoutButton = document.getElementById('checkoutButton');
            if (checkoutButton) {
                checkoutButton.classList.add('hidden');
            }
        } else {
            // Add each item to cart display
            cart.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.className = 'flex items-center justify-between py-2 border-b border-gray-200';
                itemElement.innerHTML = `
                    <div class="flex items-center">
                        <img src="${item.image}" alt="${item.name}" class="w-12 h-12 object-cover rounded ml-2">
                        <div>
                            <h4 class="text-sm font-medium">${item.name}</h4>
                            <p class="text-xs text-gray-500">${item.quantity} × ${item.price.toFixed(2)} ريال</p>
                        </div>
                    </div>
                    <button class="text-red-500 hover:text-red-700 remove-from-cart" data-product-id="${item.id}">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                `;
                cartItemsElement.appendChild(itemElement);
                
                // Add event listener to remove button
                const removeButton = itemElement.querySelector('.remove-from-cart');
                removeButton.addEventListener('click', function() {
                    removeFromCart(item.id);
                });
            });
            
            // Show checkout button
            const checkoutButton = document.getElementById('checkoutButton');
            if (checkoutButton) {
                checkoutButton.classList.remove('hidden');
            }
        }
    }
    
    // Update cart count
    if (cartCountElement) {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartCountElement.textContent = totalItems;
        
        // Show/hide cart count badge
        if (totalItems > 0) {
            cartCountElement.classList.remove('hidden');
        } else {
            cartCountElement.classList.add('hidden');
        }
    }
    
    // Update cart total
    if (cartTotalElement) {
        const totalPrice = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        cartTotalElement.textContent = totalPrice.toFixed(2) + ' ريال';
    }
}

// Payment methods
function initializePaymentMethods() {
    const paymentMethodRadios = document.querySelectorAll('input[name="paymentMethod"]');
    const paypalContainer = document.getElementById('paypalContainer');
    const creditCardContainer = document.getElementById('creditCardContainer');
    const applePayContainer = document.getElementById('applePayContainer');
    const googlePayContainer = document.getElementById('googlePayContainer');
    
    if (paymentMethodRadios.length > 0) {
        paymentMethodRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                // Hide all payment containers
                if (paypalContainer) paypalContainer.classList.add('hidden');
                if (creditCardContainer) creditCardContainer.classList.add('hidden');
                if (applePayContainer) applePayContainer.classList.add('hidden');
                if (googlePayContainer) googlePayContainer.classList.add('hidden');
                
                // Show selected payment container
                const selectedMethod = this.value;
                if (selectedMethod === 'paypal' && paypalContainer) {
                    paypalContainer.classList.remove('hidden');
                } else if (selectedMethod === 'credit-card' && creditCardContainer) {
                    creditCardContainer.classList.remove('hidden');
                } else if (selectedMethod === 'apple-pay' && applePayContainer) {
                    applePayContainer.classList.remove('hidden');
                } else if (selectedMethod === 'google-pay' && googlePayContainer) {
                    googlePayContainer.classList.remove('hidden');
                }
            });
        });
        
        // Trigger change event on the first radio button to initialize the view
        paymentMethodRadios[0].checked = true;
        paymentMethodRadios[0].dispatchEvent(new Event('change'));
    }
}

// Order submission
function submitOrder(event) {
    event.preventDefault();
    
    // Get cart items
    const cart = JSON.parse(localStorage.getItem('ebooksCart')) || [];
    if (cart.length === 0) {
        showNotification('سلة التسوق فارغة', 'error');
        return;
    }
    
    // Get form data
    const form = document.getElementById('checkoutForm');
    const formData = new FormData(form);
    
    // Create order object
    const order = {
        customer: {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone')
        },
        items: cart,
        paymentMethod: formData.get('paymentMethod'),
        total: cart.reduce((total, item) => total + (item.price * item.quantity), 0),
        date: new Date().toISOString()
    };
    
    // Send order to Google Sheets
    sendOrderToGoogleSheets(order)
        .then(response => {
            if (response.success) {
                // Clear cart
                localStorage.removeItem('ebooksCart');
                
                // Show success message
                showNotification('تم إرسال طلبك بنجاح!', 'success');
                
                // Redirect to confirmation page
                setTimeout(() => {
                    window.location.href = 'order-confirmation.html?orderId=' + response.orderId;
                }, 2000);
            } else {
                showNotification('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.', 'error');
            }
        })
        .catch(error => {
            console.error('Error submitting order:', error);
            showNotification('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.', 'error');
        });
}

// Send order to Google Sheets
function sendOrderToGoogleSheets(order) {
    // Replace with your Google Apps Script Web App URL
    const scriptURL = 'YOUR_GOOGLE_SCRIPT_WEB_APP_URL';
    
    return fetch(scriptURL, {
        method: 'POST',
        body: JSON.stringify(order),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        return {
            success: true,
            orderId: data.orderId || Date.now().toString()
        };
    })
    .catch(error => {
        console.error('Error sending order to Google Sheets:', error);
        return {
            success: false,
            error: error.message
        };
    });
}

// Utility functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-lg text-white z-50 ${type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-indigo-500'}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.classList.add('opacity-0', 'transition-opacity', 'duration-500');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 3000);
}

// Google Sheets integration for order tracking
function setupGoogleSheetsIntegration() {
    // This function will be called when the Google Sheets API is loaded
    console.log('Google Sheets API loaded');
}

// Load Google Sheets API
function loadGoogleSheetsAPI() {
    const script = document.createElement('script');
    script.src = 'https://apis.google.com/js/api.js';
    script.onload = function() {
        gapi.load('client', setupGoogleSheetsIntegration);
    };
    document.head.appendChild(script);
}

// Call this function to load the Google Sheets API
// loadGoogleSheetsAPI();
