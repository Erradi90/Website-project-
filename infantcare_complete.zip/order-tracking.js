// order-tracking.js
// JavaScript for order tracking and management

document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the order confirmation page
    if (window.location.pathname.includes('order-confirmation.html')) {
        loadOrderDetails();
    }
    
    // Check if we're on an admin page (if implemented)
    if (window.location.pathname.includes('admin-orders.html')) {
        loadAllOrders();
    }
});

// Load order details for confirmation page
function loadOrderDetails() {
    // Get order ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    
    if (!orderId) {
        showNotification('رقم الطلب غير صالح', 'error');
        setTimeout(() => {
            window.location.href = 'ebooks.html';
        }, 2000);
        return;
    }
    
    // Set order number in the UI
    const orderNumberElement = document.getElementById('orderNumber');
    if (orderNumberElement) {
        orderNumberElement.textContent = orderId;
    }
    
    // In a real implementation, we would fetch order details from the server
    // For demonstration, we'll use localStorage or simulate data
    
    // Try to get order details from localStorage (if stored during checkout)
    const orderDetails = localStorage.getItem('lastOrderDetails');
    
    if (orderDetails) {
        // Parse order details
        const order = JSON.parse(orderDetails);
        displayOrderDetails(order);
    } else {
        // Simulate order details for demonstration
        simulateOrderDetails(orderId);
    }
}

// Display order details in the UI
function displayOrderDetails(order) {
    // Customer information
    document.getElementById('customerName').textContent = order.customer.name;
    document.getElementById('customerEmail').textContent = order.customer.email;
    document.getElementById('customerPhone').textContent = order.customer.phone;
    document.getElementById('orderDate').textContent = new Date(order.date).toLocaleDateString('ar-SA');
    
    // Payment method
    const paymentMethodMap = {
        'paypal': 'PayPal',
        'credit-card': 'بطاقة ائتمان',
        'apple-pay': 'Apple Pay',
        'google-pay': 'Google Pay'
    };
    document.getElementById('paymentMethod').textContent = paymentMethodMap[order.paymentMethod] || order.paymentMethod;
    
    // Order items
    const orderItemsContainer = document.getElementById('orderItems');
    orderItemsContainer.innerHTML = '';
    
    order.items.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'flex justify-between items-center py-2 border-b border-gray-100';
        itemElement.innerHTML = `
            <div>
                <span class="font-medium text-gray-800">${item.name}</span>
                <span class="text-gray-500 text-sm block">الكمية: ${item.quantity}</span>
            </div>
            <span class="font-medium">${(item.price * item.quantity).toFixed(2)} ريال</span>
        `;
        orderItemsContainer.appendChild(itemElement);
    });
    
    // Calculate totals
    const subtotal = order.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    const tax = subtotal * 0.15;
    const total = subtotal + tax;
    
    // Update total elements
    document.getElementById('subtotal').textContent = subtotal.toFixed(2) + ' ريال';
    document.getElementById('tax').textContent = tax.toFixed(2) + ' ريال';
    document.getElementById('total').textContent = total.toFixed(2) + ' ريال';
    
    // Clear localStorage after displaying order details
    localStorage.removeItem('lastOrderDetails');
}

// Simulate order details for demonstration
function simulateOrderDetails(orderId) {
    // Create sample order data
    const order = {
        id: orderId,
        date: new Date().toISOString(),
        customer: {
            name: 'محمد أحمد',
            email: 'mohammed@example.com',
            phone: '+966 50 123 4567'
        },
        paymentMethod: 'paypal',
        items: [
            { id: 'book1', name: 'دليل التغذية السليمة للرضع', price: 45, quantity: 1 },
            { id: 'book2', name: 'أسرار نوم الطفل الهادئ', price: 35, quantity: 1 }
        ]
    };
    
    // Display the simulated order details
    displayOrderDetails(order);
}

// For admin page: Load all orders
function loadAllOrders() {
    // In a real implementation, we would fetch orders from the server/Google Sheets
    // For demonstration, we'll simulate data
    
    const orders = [
        {
            id: 'ORD-123456-7890',
            date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
            customer: {
                name: 'محمد أحمد',
                email: 'mohammed@example.com',
                phone: '+966 50 123 4567'
            },
            paymentMethod: 'paypal',
            total: 92,
            status: 'Completed'
        },
        {
            id: 'ORD-123456-7891',
            date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
            customer: {
                name: 'فاطمة علي',
                email: 'fatima@example.com',
                phone: '+966 50 987 6543'
            },
            paymentMethod: 'credit-card',
            total: 55,
            status: 'Completed'
        },
        {
            id: 'ORD-123456-7892',
            date: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
            customer: {
                name: 'أحمد محمود',
                email: 'ahmed@example.com',
                phone: '+966 50 456 7890'
            },
            paymentMethod: 'apple-pay',
            total: 199,
            status: 'Pending'
        }
    ];
    
    displayOrdersList(orders);
}

// Display orders list in admin page
function displayOrdersList(orders) {
    const ordersTableBody = document.getElementById('ordersTableBody');
    if (!ordersTableBody) return;
    
    ordersTableBody.innerHTML = '';
    
    orders.forEach(order => {
        const row = document.createElement('tr');
        
        // Format date
        const orderDate = new Date(order.date);
        const formattedDate = orderDate.toLocaleDateString('ar-SA') + ' ' + 
                             orderDate.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
        
        // Status class
        let statusClass = '';
        switch(order.status) {
            case 'Completed':
                statusClass = 'bg-green-100 text-green-800';
                break;
            case 'Pending':
                statusClass = 'bg-yellow-100 text-yellow-800';
                break;
            case 'Cancelled':
                statusClass = 'bg-red-100 text-red-800';
                break;
            default:
                statusClass = 'bg-gray-100 text-gray-800';
        }
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">${order.id}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">${formattedDate}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">${order.customer.name}</div>
                <div class="text-sm text-gray-500">${order.customer.email}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">${order.paymentMethod}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">${order.total.toFixed(2)} ريال</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                    ${order.status}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-left text-sm font-medium">
                <a href="#" class="text-indigo-600 hover:text-indigo-900 view-order" data-order-id="${order.id}">عرض</a>
                <a href="#" class="text-indigo-600 hover:text-indigo-900 ml-4 update-status" data-order-id="${order.id}">تحديث الحالة</a>
            </td>
        `;
        
        ordersTableBody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    document.querySelectorAll('.view-order').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const orderId = this.getAttribute('data-order-id');
            viewOrderDetails(orderId);
        });
    });
    
    document.querySelectorAll('.update-status').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const orderId = this.getAttribute('data-order-id');
            showUpdateStatusModal(orderId);
        });
    });
}

// View order details (admin function)
function viewOrderDetails(orderId) {
    // In a real implementation, we would fetch order details from the server
    // For demonstration, we'll simulate opening a modal with order details
    console.log(`Viewing details for order: ${orderId}`);
    
    // Simulate finding the order
    const order = {
        id: orderId,
        date: new Date(Date.now() - 86400000).toISOString(),
        customer: {
            name: 'محمد أحمد',
            email: 'mohammed@example.com',
            phone: '+966 50 123 4567'
        },
        paymentMethod: 'paypal',
        items: [
            { id: 'book1', name: 'دليل التغذية السليمة للرضع', price: 45, quantity: 1 },
            { id: 'book2', name: 'أسرار نوم الطفل الهادئ', price: 35, quantity: 1 }
        ],
        status: 'Completed'
    };
    
    // Show order details modal (implementation would depend on your UI framework)
    alert(`تفاصيل الطلب: ${orderId}\nالعميل: ${order.customer.name}\nالمجموع: ${order.items.reduce((sum, item) => sum + (item.price * item.quantity), 0)} ريال`);
}

// Show update status modal (admin function)
function showUpdateStatusModal(orderId) {
    // In a real implementation, we would show a modal to update order status
    // For demonstration, we'll simulate with a prompt
    const newStatus = prompt(`تحديث حالة الطلب ${orderId}. أدخل الحالة الجديدة (Completed, Pending, Cancelled):`);
    
    if (newStatus) {
        updateOrderStatus(orderId, newStatus);
    }
}

// Update order status (admin function)
function updateOrderStatus(orderId, status) {
    // In a real implementation, we would send this to the server/Google Sheets
    console.log(`Updating order ${orderId} status to: ${status}`);
    
    // Simulate success
    showNotification(`تم تحديث حالة الطلب ${orderId} إلى ${status}`, 'success');
    
    // Refresh orders list
    setTimeout(() => {
        loadAllOrders();
    }, 1000);
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-lg text-white z-50 ${type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-indigo-500'}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.classList.add('opacity-0', 'transition-opacity', 'duration-500');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 3000);
}

// Store order details for confirmation page
function storeOrderDetails(order) {
    localStorage.setItem('lastOrderDetails', JSON.stringify(order));
}
